#!/usr/bin/env python
import rospy
from hk_io_board.msg import pwm_signal
from hk_usb_io import *
from sfr_constants import *
import sys
import time

usb = init()

rospy.loginfo(module_version())
rospy.loginfo(rom_version(usb))
rospy.loginfo('-------output--------')

# SPI SFR constants
pwm = Bunch(pic_registers)
bit = Bunch(pic_bits)

#------------- PWM init code ------------
#		//- Duty Cycle Ratio = CCPR1L:CCP1CON<5:4> / 4 * (PR2 + 1)
#		//- 50 %   =        400          * 1/48,000,000 * 16
#		CCPR1L = 0x64; //- 50%
#		T2CON |= 0x06;   prescaler x16
def pwm_init(duty_cycle):
        sfr_set_reg(   usb, pwm.OSCCON, 0b00000110)
        
	sfr_set_regbit(usb, pwm.ANSELD, 5, 0)	# RD5 digital (P1B)
	sfr_set_regbit(usb, pwm.TRISD,  5, dir_input)	# RD5 is input for now
	sfr_set_reg(   usb, pwm.CCPTMRS, 0x00)	# select timer resource 
	#- PWM Period = [PR2 + 1] * 4 * TOSC * TMR2 Prescale Value
	#- 3,750 Hz   = (199 + 1) * 4 * 1/48,000,000 * 16
	#PR2 = 199;
	sfr_set_reg(   usb, pwm.PR2, 199)	# load with PWM period value
        #sfr_set_reg(   usb, pwm.TOSC, int(1/24000000))
        # enable pwm mode bit(3-0), bit(5-4) LSB PWM duty cycle
	sfr_set_reg(   usb, pwm.CCP1CON, 0b00001100)
	sfr_set_reg(   usb, pwm.CCPR1L, 0x00)	# eight high bits of duty cycle
	# Timer2 on, 1:1 Post, 16x prescale
	sfr_set_reg(   usb, pwm.T2CON, 0b00000110)
	sfr_set_regbit(usb, pwm.PSTR1CON, 1, 1)	# enable STR1B to assign PxB
	sfr_set_regbit(usb, pwm.TRISD,  5, dir_output)	# RD5 enabled for output
        sfr_set_reg(   usb, pwm.TMR2, 64)
	# LSB of PWM duty cycle
	#- Duty Cycle Ratio = CCPR1L:CCP1CON<5:4> / 4 * (PR2 + 1)
	#- 50 %   =        400          * 1/48,000,000 * 16
	#CCPR1L = 0x64; //- 50%
	sfr_set_reg(usb, pwm.CCPR1L, duty_cycle)

def callback(data):
    rospy.loginfo("Received pwm: %f" % (data.pwm))
    pwm_init(100)

def listen():
    rospy.init_node('pwm_control', anonymous=True)
    rospy.Subscriber('pwm_out', pwm_signal, callback)
    rospy.spin()

if __name__ == '__main__':
    try:
        listen();
    except rospy.ROSInterruptException: pass
