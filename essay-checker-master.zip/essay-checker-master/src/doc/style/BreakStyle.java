package doc.style;

import doc.DocPosition;
import doc.Document;

public class BreakStyle extends StyleDef {
	private DocPosition m_position;

	public BreakStyle(DocPosition pos) {
		m_position = pos;
	}

	@Override
	public void applyStyle(Document doc) {
		doc.insertText(m_position, "<br><br>");
	}

	@Override
	public StyleDef cloneFor(Document doc) {
		DocPosition newPos = doc.createPosition(m_position.index);
		return new BreakStyle(newPos);
	}
}
