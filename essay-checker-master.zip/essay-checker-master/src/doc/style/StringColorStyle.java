package doc.style;

import doc.DocPosition;
import doc.Document;

public class StringColorStyle extends StyleDef {
	private DocPosition m_position;
	private int m_length;
	private String m_color;

	public StringColorStyle(DocPosition pos, int length, String color) {
		m_position = pos;
		m_length = length;
		m_color = color;
	}

	@Override
	public void applyStyle(Document doc) {
		doc.insertText(doc.createPosition(m_position.index + m_length), "</font>");
		doc.insertText(m_position, "<font color=\"" + m_color + "\">");
	}

	@Override
	public StyleDef cloneFor(Document doc) {
		DocPosition newPos = doc.createPosition(m_position.index);
		return new StringColorStyle(newPos, m_length, m_color);
	}
}
