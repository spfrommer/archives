package doc.style;

import doc.Document;

public abstract class StyleDef {
	public abstract void applyStyle(Document doc);

	public abstract StyleDef cloneFor(Document doc);
}
