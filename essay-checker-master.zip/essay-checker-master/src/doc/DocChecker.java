package doc;

import gui.DocViewer;
import gui.plugin.RepeatWordPlugin;

public class DocChecker {
	public static void main(String[] args) {
		Document doc = DocFactory.docFromFile("resources/essay.txt");
		DocViewer viewer = new DocViewer(doc);
		viewer.addPlugin(new RepeatWordPlugin());
		viewer.runPlugins();
		viewer.displayText();
		viewer.show();
	}
}
