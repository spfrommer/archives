package doc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;

public class DocFactory {
	private DocFactory() {

	}

	public static Document docFromFile(String file) {
		URL res = DocFactory.class.getClassLoader().getResource(file);
		BufferedReader reader = null;

		try {
			reader = new BufferedReader(new FileReader(new File(res.toURI())));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}

		try {
			StringBuilder sb = new StringBuilder();
			String line = reader.readLine();

			while (line != null) {
				sb.append(line + System.lineSeparator());
				line = reader.readLine();
			}
			return new Document(file, sb.toString());
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return new Document("none", "error");
	}
}
