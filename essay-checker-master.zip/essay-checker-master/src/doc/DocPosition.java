package doc;

public class DocPosition {
	public int index;

	public DocPosition(int index) {
		this.index = index;
	}

	public void increment(int amount) {
		index += amount;
	}
}
