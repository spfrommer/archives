package doc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import doc.style.BreakStyle;
import doc.style.StyleDef;

public class Document {
	private String m_title;
	private String m_doc;

	private Map<Object, List<StyleDef>> m_styles = new HashMap<Object, List<StyleDef>>();
	private List<DocPosition> m_positions = new ArrayList<DocPosition>();

	public Document(String title, String doc) {
		m_title = title;
		m_doc = doc;
	}

	public Document deepClone() {
		Document doc = new Document(new String(m_title), new String(m_doc));
		for (Object obj : m_styles.keySet()) {
			List<StyleDef> styles = m_styles.get(obj);
			for (StyleDef def : styles) {
				doc.addStyleDef(obj, def.cloneFor(doc));
			}
		}
		return doc;
	}

	public String getTitle() {
		return m_title;
	}

	public DocPosition createPosition(int index) {
		DocPosition position = new DocPosition(index);
		m_positions.add(position);
		return position;
	}

	public Document addDocPosition(DocPosition position) {
		m_positions.add(position);
		return this;
	}

	public Document addStyleDef(Object key, StyleDef style) {
		if (!m_styles.containsKey(key))
			m_styles.put(key, new ArrayList<StyleDef>());
		m_styles.get(key).add(style);

		return this;
	}

	public Document removeAllStyleDefs(Object key) {
		if (m_styles.containsKey(key)) {
			m_styles.get(key).clear();
		}

		return this;
	}

	public Document applyStyles() {
		for (List<StyleDef> defs : m_styles.values()) {
			for (StyleDef def : defs)
				def.applyStyle(this);
		}

		return this;
	}

	public Document insertText(DocPosition position, String text) {
		int textLen = text.length();
		m_doc = insertString(m_doc, text, position.index);
		for (DocPosition pos : m_positions) {
			if (pos.index > position.index) {
				pos.increment(textLen);
			}
		}

		return this;
	}

	private String insertString(String to, String from, int position) {
		String before = to.substring(0, position);
		String after = to.substring(position);
		return before + from + after;
	}

	public Document toHTMLDoc() {
		Document html = this.deepClone();
		int index = 0;
		while ((index = m_doc.indexOf('\n', index)) != -1) {
			// System.out.println("Adding break style:" + index);
			html.addStyleDef(html, new BreakStyle(html.createPosition(index)));
			index += 6;
		}
		return html;
	}

	@Override
	public String toString() {
		return m_doc;
	}
}
