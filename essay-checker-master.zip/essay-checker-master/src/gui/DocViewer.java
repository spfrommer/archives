package gui;

import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.text.DefaultCaret;

import doc.Document;

public class DocViewer {
	private JFrame m_frame;
	private JTextPane m_txt;
	private Document m_doc;
	private List<JPanel> m_panels = new ArrayList<JPanel>();
	private List<ViewPlugin> m_plugins = new ArrayList<ViewPlugin>();

	{
		m_frame = new JFrame("Essay Checker");
		m_frame.setSize(800, 800);
		m_frame.setLayout(new BorderLayout());
		m_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		m_txt = new JTextPane();
		m_txt.setContentType("text/html");
		DefaultCaret caret = (DefaultCaret) m_txt.getCaret();
		caret.setUpdatePolicy(DefaultCaret.NEVER_UPDATE);

		JScrollPane jsp = new JScrollPane(m_txt);
		m_frame.add(jsp, BorderLayout.CENTER);
	}

	public DocViewer() {
	}

	public DocViewer(Document doc) {
		setDoc(doc);
	}

	public Document getDocument() {
		return m_doc;
	}

	public void setDoc(Document doc) {
		m_doc = doc;
	}

	public void addPlugin(ViewPlugin plugin) {
		m_plugins.add(plugin);
		plugin.setViewer(this);
	}

	public void runPlugins() {
		for (JPanel p : m_panels) {
			m_frame.remove(p);
		}

		for (ViewPlugin plugin : m_plugins) {
			plugin.run();
		}
	}

	public void displayText() {
		String text = m_doc.toHTMLDoc().applyStyles().toString();

		m_txt.setContentType("text/html");
		m_txt.setText(text);
	}

	public JPanel createPanel(String position) {
		JPanel panel = new JPanel();
		m_panels.add(panel);
		m_frame.add(panel, position);
		return panel;
	}

	public void show() {
		m_frame.setVisible(true);
	}

	public void hide() {
		m_frame.setVisible(false);
	}
}
