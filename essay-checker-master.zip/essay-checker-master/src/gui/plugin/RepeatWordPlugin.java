package gui.plugin;

import gui.DocViewer;
import gui.ViewPlugin;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import doc.Document;
import doc.style.RGBColorStyle;

public class RepeatWordPlugin extends ViewPlugin {
	private static final List<String> ARTICLES = Arrays.asList(new String[] { "a", "an", "the" });
	private static final List<String> CONJUNCTIONS = Arrays.asList(new String[] { "for", "and", "but", "or", "yet",
			"so" });
	private static final List<String> PREPOSITIONS = Arrays.asList(new String[] { "in", "with", "of", "by", "to",
			"from" });
	private static final List<String> RELATIVE_PRONOUNS = Arrays.asList(new String[] { "which", "who", "that", "when",
			"where" });
	private static final List<String> TO_BE = Arrays.asList(new String[] { "be", "am", "are", "is", "was", "were",
			"being", "been" });
	private static final List<String> HELPING_VERBS = Arrays.asList(new String[] { "have", "has", "had", "shall",
			"will", "do", "does", "did", "may", "must", "might", "can", "could", "would", "should" });
	private static final List<String> PRONOUNS = Arrays.asList(new String[] { "this", "that", "these", "those", "here",
			"there" });

	@SuppressWarnings("unchecked")
	@Override
	public void run() {
		final DocViewer view = this.getViewer();
		final Document doc = view.getDocument();

		List<RepeatWord> repeats = getRepeatWords(doc);
		Collections.sort(repeats);

		JPanel panel = view.createPanel(BorderLayout.EAST);
		panel.setLayout(new BorderLayout());
		String[] repeatStrings = new String[repeats.size()];
		for (int i = 0; i < repeats.size(); i++) {
			RepeatWord word = repeats.get(i);
			repeatStrings[i] = word.frequency + ": " + word.word;
		}
		JList<String> list = new JList<String>(repeatStrings);
		list.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent event) {
				if (!event.getValueIsAdjusting()) {
					String string = ((JList<String>) event.getSource()).getSelectedValue().toString();
					String[] subStrings = string.split(" ");

					int frequency = Integer.valueOf(subStrings[0].substring(0, subStrings[0].length() - 1));
					String word = subStrings[1];

					doc.removeAllStyleDefs(RepeatWordPlugin.this);
					markWord(doc, word, frequency, new Color(255, 0, 0));
					view.displayText();
				}
			}
		});
		JScrollPane scroll = new JScrollPane(list);
		panel.add(scroll, BorderLayout.CENTER);
	}

	private List<RepeatWord> getRepeatWords(Document doc) {
		String[] words = doc.toString().replaceAll("[^a-zA-Z ]", " ").toLowerCase().split("\\s+");

		List<RepeatWord> repeats = new ArrayList<RepeatWord>();
		List<String> list = Arrays.asList(words);
		Set<String> uniqueWords = new HashSet<String>(list);
		for (String word : uniqueWords) {
			int freq = Collections.frequency(list, word);
			if (freq >= 2 && !ARTICLES.contains(word) && !CONJUNCTIONS.contains(word) && !PREPOSITIONS.contains(word)
					&& !RELATIVE_PRONOUNS.contains(word) && !TO_BE.contains(word) && !HELPING_VERBS.contains(word)
					&& !PRONOUNS.contains(word)) {

				repeats.add(new RepeatWord(word, freq));
			}
		}
		return repeats;
	}

	/**
	 * Marks freq instances of a word a certain Color.
	 * 
	 * @param doc
	 * @param word
	 * @param freq
	 * @param color
	 */
	private void markWord(Document doc, String word, int freq, Color color) {
		int wordlen = word.length();
		int index = -wordlen;

		for (int i = 0; i < freq; i++) {
			index = doc.toString().toLowerCase().indexOf(word, index + wordlen);

			if (isWord(index, wordlen, doc)) {
				doc.addStyleDef(this, new RGBColorStyle(doc.createPosition(index), wordlen, color));
			} else {
				i--;
			}
		}

	}

	/**
	 * Determines whether is a stand alone word, not part of another word.
	 * 
	 * @param index
	 * @param wordlen
	 * @param doc
	 * @return
	 */
	private static boolean isWord(int index, int wordlen, Document doc) {
		if (index != 0) {
			char before = doc.toString().charAt(index - 1);
			if (Character.isLetter(before)) {
				return false;
			}
		}

		if (index != doc.toString().length()) {
			char after = doc.toString().charAt(index + wordlen);
			if (Character.isLetter(after)) {
				return false;
			}
		}
		return true;
	}
}
