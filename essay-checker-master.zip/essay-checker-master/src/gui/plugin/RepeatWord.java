package gui.plugin;

public class RepeatWord implements Comparable {
	public String word;
	public int frequency;

	public RepeatWord(String word, int frequency) {
		this.word = word;
		this.frequency = frequency;
	}

	@Override
	public int compareTo(Object arg0) {
		return ((RepeatWord) arg0).frequency - this.frequency;
	}
}
