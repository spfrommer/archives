package gui;


public abstract class ViewPlugin {
	private DocViewer m_view;

	public ViewPlugin() {

	}

	public ViewPlugin(DocViewer view) {
		m_view = view;
	}

	public DocViewer getViewer() {
		return m_view;
	}

	public void setViewer(DocViewer viewer) {
		m_view = viewer;
	}

	/**
	 * Called to make the ViewPlugin add a gui or modify the document.
	 * 
	 * @param doc
	 */
	public abstract void run();
}