package gui;

import java.awt.Color;

public class ColorUtils {
	private ColorUtils() {

	}

	public static String toHex(Color c) {
		return "#" + toBrowserHexValue(c.getRed()) + toBrowserHexValue(c.getGreen()) + toBrowserHexValue(c.getBlue());
	}

	private static String toBrowserHexValue(int number) {
		StringBuilder builder = new StringBuilder(Integer.toHexString(number & 0xff));
		while (builder.length() < 2) {
			builder.append("0");
		}
		return builder.toString().toUpperCase();
	}
}
