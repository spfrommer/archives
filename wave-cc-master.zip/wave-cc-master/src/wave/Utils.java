package wave;

import java.util.Calendar;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import wave.google.GAccountView;

public class Utils {
	private Utils() {

	}

	private static final String AUTH_CODE_URL = "https://accounts.google.com/o/oauth2/auth?scope=https://www.googleapis.com/auth/calendar&response_type=code&redirect_uri=urn:ietf:wg:oauth:2.0:oob&access_type=online&approval_prompt=auto&client_id=987820761543-7vrtvmdgi30ostkg4ab9r2p4p5vfbmkp.apps.googleusercontent.com&hl=en&from_login=1&as=-183778a2a529a8c8&authuser=0";
	private static final String[] MONTHS_SHORT = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep",
			"Oct", "Nov", "Dec" };

	/**
	 * Returns a Date given text in the format of "Oct 28." If the text is not
	 * in the correct format, it will return tomorrow's date.
	 * 
	 * @param text
	 * @return
	 */
	public static Date textToDate(String text) {
		String[] components = text.split(" ");
		String monthStr = components[0];
		String dayStr = components[1];

		int month = indexOfContains(MONTHS_SHORT, monthStr);
		if (month == -1) {
			// adapted from Burkhard Hassel's code ranch answer.
			Date now = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(now);
			cal.add(Calendar.DAY_OF_YEAR, 1);
			Date tomorrow = cal.getTime();
			return tomorrow;
		}
		int day = Integer.parseInt(dayStr);

		Calendar today = Calendar.getInstance();
		@SuppressWarnings("deprecation")
		Date date = new Date(today.get(Calendar.YEAR) - 1900, month, day);

		return date;
	}

	public static String getCalendarAuthCode(GAccountView account) {
		WebDriver driver = account.getDriver();
		driver.get(AUTH_CODE_URL);

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		driver.findElement(By.id("submit_approve_access")).click();
		WebElement element = driver.findElement(By.id("code"));
		String value = element.getAttribute("value");

		return value;
	}

	/**
	 * Will return the first index of the String in strings that is contained by
	 * string.
	 * 
	 * @param strings
	 * @param string
	 * @return
	 */
	private static int indexOfContains(String[] strings, String string) {
		for (int i = 0; i < strings.length; i++) {
			if (string.toLowerCase().contains(strings[i].toLowerCase()))
				return i;
		}
		return -1;
	}
}
