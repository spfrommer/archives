package wave;

public class ClassroomToCalendar {
	private String m_classroomUrl;
	private String m_calendarID;

	public ClassroomToCalendar(String classroomUrl, String calendarID) {
		m_classroomUrl = classroomUrl;
		m_calendarID = calendarID;
	}

	public String getClassroomUrl() {
		return m_classroomUrl;
	}

	public String getCalendarID() {
		return m_calendarID;
	}

	public String toString() {
		return "Classroom URL: " + m_classroomUrl + ", calendar ID: " + m_calendarID;
	}
}
