package wave.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import wave.ClassroomToCalendar;

public class ClassroomToCalendarGui {
	private static Object m_waitObject = new Object();

	private ClassroomToCalendarGui() {

	}

	public static List<ClassroomToCalendar> getClassroomToCalendars() {
		JFrame frame = new JFrame("Enter Classes");
		JPanel panel = new JPanel(new BorderLayout());

		final DefaultTableModel model = new DefaultTableModel();
		model.addColumn("Google Classroom URL");
		model.addColumn("Google Calendar ID");
		JTable entryTable = new JTable(model);

		entryTable.setGridColor(new Color(0, 0, 150));
		entryTable.setRowSelectionAllowed(false);
		entryTable.setColumnSelectionAllowed(false);
		entryTable.setShowGrid(true);
		entryTable.setDefaultRenderer(Object.class, new CustomTableCellRenderer());
		panel.add(new JScrollPane(entryTable), BorderLayout.CENTER);

		JPanel buttonPanel = new JPanel(new GridLayout(1, 2));
		JButton newRow = new JButton("Add Class");
		newRow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.addRow(new Object[] { "", "" });
			}
		});
		JButton submit = new JButton("Submit");
		submit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				synchronized (m_waitObject) {
					m_waitObject.notify();
				}
			}
		});
		buttonPanel.add(newRow);
		buttonPanel.add(submit);
		panel.add(buttonPanel, BorderLayout.SOUTH);
		frame.add(panel);
		frame.setSize(500, 500);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		synchronized (m_waitObject) {
			try {
				m_waitObject.wait();
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		}

		frame.setVisible(false);
		return getTableData(entryTable);
	}

	private static List<ClassroomToCalendar> getTableData(JTable table) {
		List<ClassroomToCalendar> ccs = new ArrayList<ClassroomToCalendar>();
		DefaultTableModel dtm = (DefaultTableModel) table.getModel();
		int nRow = dtm.getRowCount();
		for (int i = 0; i < nRow; i++) {
			ccs.add(new ClassroomToCalendar((String) dtm.getValueAt(i, 0), (String) dtm.getValueAt(i, 1)));
		}
		return ccs;
	}

	public static void main(String[] args) {
		List<ClassroomToCalendar> ccms = ClassroomToCalendarGui.getClassroomToCalendars();
		for (ClassroomToCalendar ccm : ccms) {
			System.out.println(ccm.getClassroomUrl() + " : " + ccm.getCalendarID());
		}
	}
}
