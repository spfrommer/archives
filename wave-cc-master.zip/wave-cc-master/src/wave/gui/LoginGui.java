package wave.gui;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginGui {
	private static Object m_waitObject = new Object();

	private LoginGui() {

	}

	@SuppressWarnings("deprecation")
	public static String[] getLoginInfo(String title) {
		JFrame frame = new JFrame(title);
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(7, 1));

		JTextField saveDir = new JTextField("");
		JTextField username = new JTextField("");
		JPasswordField password = new JPasswordField("");
		panel.add(new JLabel("  Enter credential save directory: "));
		panel.add(saveDir);
		panel.add(new JLabel("  Enter username: "));
		panel.add(username);
		panel.add(new JLabel("  Enter password: "));
		panel.add(password);

		JButton authenticate = new JButton("Authenticate");
		authenticate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				synchronized (m_waitObject) {
					m_waitObject.notify();
				}
			}
		});
		panel.add(authenticate);

		frame.add(panel);
		frame.setSize(300, 250);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setVisible(true);

		try {
			synchronized (m_waitObject) {
				m_waitObject.wait();
			}
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		frame.setVisible(false);
		return new String[] { saveDir.getText(), username.getText(), password.getText() };
	}
}
