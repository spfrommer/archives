package wave.gui;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 * Taken from mkukuluk's StackOverflow question
 * "Swing JTable - Highlight selected cell in a different color from rest of the selected row?"
 * .
 */
public class CustomTableCellRenderer extends DefaultTableCellRenderer {
	public final DefaultTableCellRenderer DEFAULT_RENDERER = new DefaultTableCellRenderer();

	@Override
	public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
			int row, int column) {
		Component c = DEFAULT_RENDERER.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

		if (isSelected) {
			c.setBackground(Color.red);
		} else {
			c.setForeground(Color.black);
			c.setBackground(Color.white);
		}
		return c;
	}
}