package wave.gui;

import java.awt.Frame;

import javax.swing.JFrame;

/**
 * A gui to cover up the ugly Firefox windows spawning.
 */
public class CoverupGui {
	private JFrame m_cover = new JFrame();

	private CoverupGui() {

	}

	public void startCoverup() {
		m_cover.setExtendedState(Frame.MAXIMIZED_BOTH);
		m_cover.setResizable(false);
		m_cover.setUndecorated(true);
		m_cover.setAlwaysOnTop(true);

		m_cover.add(new CoverupPanel());
		m_cover.setVisible(true);
	}

	public void stopCoverup() {
		m_cover.setVisible(false);
	}

	private static CoverupGui INSTANCE;

	public static CoverupGui instance() {
		if (INSTANCE == null)
			INSTANCE = new CoverupGui();

		return INSTANCE;
	}

	public static void main(String[] args) {
		CoverupGui.instance().startCoverup();
	}
}
