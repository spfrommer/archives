package wave.gui;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;

public class CoverupPanel extends JPanel {
	private static final long serialVersionUID = -5432380149132166790L;
	private Image m_background;
	private Image m_arrow;
	private double m_rot;

	private Font m_font = new Font("Tahoma", Font.PLAIN, 12);
	private long m_lastMessageChangeTime = System.currentTimeMillis();
	private static final long MESSAGE_TIME = 4000;
	private String m_currentMessage;
	private List<Integer> m_displayedMessages = new ArrayList<Integer>();
	private static final String[] MESSAGES = new String[] { "Orphaning Firefox processes", "Scraping Google Classroom",
			"Accessing Google Calendar API", "Gathering assignments", "Creating assignments list",
			"Cross-checking existing assignments", "Updating calendar", "Parsing classes",
			"Whoops! Just erased a few system files!", "Spamming message forums", "Downloading contacts",
			"Stealing orange juice", "ASDFASDFASDFASDF", "Filling in missing assignments", "Starting Selenium",
			"Reverse Engineering Binary", "Reading xkcd comics", "Taking coffee break", "Starting board meeting" };

	public CoverupPanel() {
		Timer t = new Timer(10, new Listener());
		t.start();
		try {
			m_background = ImageIO.read(this.getClass().getResourceAsStream("arrowbackground.png"));
			m_arrow = ImageIO.read(this.getClass().getResourceAsStream("arrow.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		pickNewMessage();
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		Graphics2D g2d = (Graphics2D) g;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		drawMessages(g2d);
		drawArrow(g2d);

		g2d.dispose();
	}

	private void drawMessages(Graphics2D g2d) {
		long curTime = System.currentTimeMillis();
		if (curTime - m_lastMessageChangeTime > MESSAGE_TIME) {
			m_lastMessageChangeTime = curTime;
			pickNewMessage();
		}

		g2d.setFont(m_font);
		int width = this.getWidth();
		int height = this.getHeight();
		g2d.drawString(m_currentMessage, width / 2 - getWidth(m_currentMessage) / 2, height - 100);
	}

	private void pickNewMessage() {
		int rand = (int) (Math.random() * MESSAGES.length);
		if (!m_displayedMessages.contains(rand)) {
			m_currentMessage = MESSAGES[rand];
			m_displayedMessages.add(rand);
		} else if (m_displayedMessages.size() < MESSAGES.length) {
			pickNewMessage();
		}
	}

	private void drawArrow(Graphics2D g2d) {
		int width = this.getWidth();
		int height = this.getHeight();
		g2d.translate(width / 2, height / 2);
		g2d.drawImage(m_background, -m_background.getWidth(null) / 2, -m_background.getHeight(null) / 2, null);
		g2d.rotate(m_rot);
		g2d.drawImage(m_arrow, -m_arrow.getWidth(null) / 2, -m_arrow.getHeight(null) / 2, null);

		m_rot += 0.02f;
	}

	private int getWidth(String text) {
		AffineTransform affinetransform = new AffineTransform();
		FontRenderContext frc = new FontRenderContext(affinetransform, true, true);

		int textWidth = (int) (m_font.getStringBounds(text, frc).getWidth());
		return textWidth;
	}

	private class Listener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			CoverupPanel.this.repaint();
		}
	}
}