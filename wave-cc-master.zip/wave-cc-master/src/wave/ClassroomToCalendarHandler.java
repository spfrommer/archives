package wave;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import wave.gui.ClassroomToCalendarGui;

public class ClassroomToCalendarHandler {
	private static final String CC_FILE = ".ccs";

	private ClassroomToCalendarHandler() {

	}

	public List<ClassroomToCalendar> getClassroomToCalendars() {
		String fileLoc = LoginHandler.instance().getDir();
		String file = fileLoc + File.separator + CC_FILE;
		List<ClassroomToCalendar> ccs = new ArrayList<ClassroomToCalendar>();

		if (new File(file).exists()) {
			try {
				Scanner reader = new Scanner(new FileReader(file));
				while (reader.hasNextLine()) {
					ccs.add(new ClassroomToCalendar(reader.nextLine(), reader.nextLine()));
				}
				reader.close();
			} catch (FileNotFoundException e) {
				System.out.println("Read failed!");
				e.printStackTrace();
			}
		} else {
			ccs = ClassroomToCalendarGui.getClassroomToCalendars();

			PrintWriter writer = null;
			try {
				writer = new PrintWriter(file, "UTF-8");
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}

			for (ClassroomToCalendar cc : ccs) {
				writer.println(cc.getClassroomUrl());
				writer.println(cc.getCalendarID());
			}
			writer.close();
		}
		return ccs;
	}

	private static ClassroomToCalendarHandler INSTANCE;

	public static ClassroomToCalendarHandler instance() {
		if (INSTANCE == null)
			INSTANCE = new ClassroomToCalendarHandler();

		return INSTANCE;
	}

	public static void main(String[] args) {
		for (ClassroomToCalendar cc : ClassroomToCalendarHandler.instance().getClassroomToCalendars()) {
			System.out.println(cc);
		}
	}
}
