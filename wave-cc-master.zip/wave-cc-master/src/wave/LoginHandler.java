package wave;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;
import java.util.prefs.Preferences;

import wave.google.GCredentials;
import wave.gui.LoginGui;

public class LoginHandler {
	private Preferences m_prefs;
	private String m_dir;
	private String m_user;
	private String m_pwd;
	private String m_guiTitle = "Authenticate";

	private static final String AUTH_FILE = ".creds";

	private LoginHandler() {
		m_prefs = Preferences.userNodeForPackage(this.getClass());
		m_dir = m_prefs.get("dir", "");
	}

	public GCredentials getCredentials() {
		if (m_user != null && m_pwd != null)
			return new GCredentials(m_user, m_pwd);

		if (m_dir == null || m_dir.length() == 0) {
			String[] loginInfo = LoginGui.getLoginInfo(m_guiTitle);
			m_dir = formatDir(loginInfo[0]);
			m_user = loginInfo[1];
			m_pwd = loginInfo[2];

			m_prefs.put("dir", m_dir);
			try {
				if (!new File(m_dir).exists()) {
					return reaskCredentials();
				}
				PrintWriter writer = new PrintWriter(m_dir + File.separator + AUTH_FILE, "UTF-8");
				writer.println(m_user);
				writer.println(m_pwd);
				writer.close();
			} catch (FileNotFoundException e) {
				return reaskCredentials();
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		} else {
			try {
				Scanner reader = new Scanner(new FileReader(m_dir + File.separator + AUTH_FILE));
				m_user = reader.nextLine();
				m_pwd = reader.nextLine();
				reader.close();
			} catch (FileNotFoundException e) {
				System.out.println("Read failed!");
				return reaskCredentials();
			}
		}
		return new GCredentials(m_user, m_pwd);
	}

	public String getDir() {
		return m_dir;
	}

	private String formatDir(String dir) {
		if (dir.charAt(dir.length() - 1) == File.separatorChar)
			dir = dir.substring(0, dir.length() - 1);
		return dir;
	}

	private GCredentials reaskCredentials() {
		m_prefs.put("dir", "");
		m_dir = "";
		m_user = null;
		m_pwd = null;
		m_guiTitle = "Directory Not Found";
		return getCredentials();
	}

	private static LoginHandler s_instance;

	public static LoginHandler instance() {
		if (s_instance == null)
			s_instance = new LoginHandler();

		return s_instance;
	}
}
