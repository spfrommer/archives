package wave.google;

public class GCredentials {
	private String m_username;
	private String m_password;

	public GCredentials(String username, String password) {
		m_username = username;
		m_password = password;
	}

	public String getUsername() {
		return m_username;
	}

	public String getPassword() {
		return m_password;
	}

	@Override
	public String toString() {
		return "User: " + m_username + ", Password: " + m_password;
	}
}
