package wave.google;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class GAccountView {
	private GCredentials m_credentials;
	private FirefoxDriver m_driver;
	private static final String LOGIN_URL = "https://accounts.google.com/ServiceLogin?sacu=1&hl=en";

	public GAccountView(GCredentials credentials) {
		m_credentials = credentials;
	}

	public GCredentials getCredentials() {
		return m_credentials;
	}

	/**
	 * Returns the already signed-in WebDriver.
	 * 
	 * @return
	 */
	public WebDriver getDriver() {
		if (m_driver == null)
			login();
		return m_driver;
	}

	public void close() {
		m_driver.quit();
	}

	private void login() {
		m_driver = new FirefoxDriver();
		// m_driver = new HtmlUnitDriver(true);
		// m_driver.setJavascriptEnabled(true);

		System.out.println("Starting sign in");
		m_driver.get(LOGIN_URL);
		m_driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		m_driver.findElement(By.id("Email")).clear();
		m_driver.findElement(By.id("Email")).sendKeys(m_credentials.getUsername());
		m_driver.findElement(By.id("Passwd")).clear();
		m_driver.findElement(By.id("Passwd")).sendKeys(m_credentials.getPassword());
		System.out.println("Pushing button");
		m_driver.findElement(By.id("signIn")).click();

		System.out.println("Signed in");
	}
}
