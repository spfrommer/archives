package wave.google;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import wave.Assignment;
import wave.Utils;

public class GClassroom {
	private GAccountView m_account;
	private static final boolean IS_STUDENT = true;
	private static final String DIV_ASSIGNMENT_CLASS = ".laUEs ";
	private static final String NOTIFICATION_TYPE_CLASS = ".DT6nrc.DWxSed";
	private static final String NOTIFICATION_ASSIGNMENT = "ASSIGNMENT";
	private static final String NOTIFICATION_ANNOUNCEMENT = "ANNOUNCEMENT";
	private static final String TEACHER_ASSIGNMENT_DATE_START_CLASS = ".onkcGd.TMagrf.zZN2Lb-Wvd9Cc.VBEdtc-Wvd9Cc";
	private static final String TEACHER_ASSIGNMENT_DATE_END_CLASS = ".gpkaqb";
	private static final String TEACHER_ANNOUNCEMENT_DATE_END_CLASS = ".TMagrf";
	// for the student view, the dates are different
	private static final String STUDENT_ASSIGNMENT_DATE_END_CLASS = ".onkcGd.TMagrf.zZN2Lb-Wvd9Cc.VBEdtc-Wvd9Cc";
	private static final String STUDENT_ANNOUNCEMENT_DATE_END_CLASS = ".TMagrf";
	private static final String TITLE_CLASS = ".onkcGd.wDmdf.nk37z.zZN2Lb-Wvd9Cc.VBEdtc-Wvd9Cc";
	private static final String EXTENDED_CLASS = ".b65z4e";
	private String m_classroomUrl;

	public GClassroom(GAccountView account, String classroomUrl) {
		m_account = account;
		m_classroomUrl = classroomUrl;
	}

	/**
	 * This method reloads the Assignments with a new FirefoxDriver.
	 * 
	 * @return
	 */
	public List<Assignment> loadAssignments() {
		WebDriver driver = m_account.getDriver();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.get(m_classroomUrl);
		// driver.navigate().to("file:///Users/samuel/Desktop/classroom.html");

		// System.out.println("Navigated");
		// System.out.println(driver.)
		// System.out.println(driver.getPageSource());
		List<Assignment> assignments = new ArrayList<Assignment>();
		List<WebElement> elements = driver.findElements(By.cssSelector(DIV_ASSIGNMENT_CLASS));
		for (WebElement element : elements) {
			Assignment assignment = getAssignment(element);
			if (assignment != null)
				assignments.add(assignment);
		}
		return assignments;
	}

	private Assignment getAssignment(WebElement element) {
		// System.out.println("got element");
		List<WebElement> notifications = element.findElements(By.cssSelector(NOTIFICATION_TYPE_CLASS));
		if (notifications.size() == 0) {
			// System.out.println("No notification; this is comment");
			return null;
		} else {
			WebElement notification = notifications.get(0);
			WebElement extended = element.findElement(By.cssSelector(EXTENDED_CLASS));
			String extendedText = extended.getText();
			if (notification.getText().equals(NOTIFICATION_ASSIGNMENT)) {
				WebElement date = element.findElement(By.cssSelector((IS_STUDENT) ? STUDENT_ASSIGNMENT_DATE_END_CLASS
						: TEACHER_ASSIGNMENT_DATE_END_CLASS));
				String dateString = getDateString(date);
				// System.out.println("Got assignment at date: " + dateString);
				WebElement title = element.findElement(By.cssSelector(TITLE_CLASS));
				return new Assignment(Utils.textToDate(dateString), title.getText(), extendedText);
			} else if (notification.getText().equals(NOTIFICATION_ANNOUNCEMENT)) {
				WebElement date = element.findElement(By.cssSelector((IS_STUDENT) ? STUDENT_ANNOUNCEMENT_DATE_END_CLASS
						: TEACHER_ANNOUNCEMENT_DATE_END_CLASS));
				String dateString = getDateString(date);
				// System.out.println("Got announcement at date: " +
				// dateString);
				return new Assignment(Utils.textToDate(dateString), extendedText.substring(0,
						Math.min(40, extendedText.length()))
						+ "...", extendedText);
			} else {
				return null;
				// throw new
				// RuntimeException("Notification is not assignment or announcement: "
				// + notification.getText());
			}
		}
	}

	private static String getDateString(WebElement date) {
		String dateString;
		if (IS_STUDENT) {
			dateString = date.getText();
		} else {
			dateString = date.getText().split(",")[0];
		}
		return dateString;
	}
}
