package wave.google;

import java.io.IOException;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import wave.Assignment;

import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.auth.oauth2.GoogleTokenResponse;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.DateTime;
import com.google.api.services.calendar.Calendar;
import com.google.api.services.calendar.CalendarScopes;
import com.google.api.services.calendar.model.Event;
import com.google.api.services.calendar.model.EventDateTime;

public class GCalendar {
	private Calendar m_service;
	private List<Event> m_eventCache;
	private String m_calendarId;
	// Insert client ID and clientSecret into the quotes
	private static final String CLIENT_ID = "";
	private static final String CLIENT_SECRET = "";
	private static final long DAY_LENGTH = 86400000;

	public GCalendar(GAccountView account, String calendarId, String code) {
		m_calendarId = calendarId;
		HttpTransport httpTransport = new NetHttpTransport();
		JacksonFactory jsonFactory = new JacksonFactory();

		String redirectUrl = "urn:ietf:wg:oauth:2.0:oob";
		GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(httpTransport, jsonFactory,
				CLIENT_ID, CLIENT_SECRET, Collections.singleton(CalendarScopes.CALENDAR)).setAccessType("online")
				.setApprovalPrompt("auto").build();

		try {
			GoogleTokenResponse response = flow.newTokenRequest(code).setRedirectUri(redirectUrl).execute();
			GoogleCredential credential = new GoogleCredential().setFromTokenResponse(response);

			m_service = new Calendar.Builder(httpTransport, jsonFactory, credential).build();
			m_eventCache = m_service.events().list(m_calendarId).setPageToken(null).execute().getItems();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void addAssignment(Assignment assignment) {
		Event event = new Event();
		event.setSummary(assignment.getAssignment());

		Date startDate = assignment.getDate();
		Date endDate = new Date(startDate.getTime() + DAY_LENGTH);

		DateTime start = new DateTime(startDate, TimeZone.getTimeZone("EDT"));
		DateTime end = new DateTime(endDate, TimeZone.getTimeZone("EDT"));
		event.setStart(new EventDateTime().setDateTime(start));
		event.setEnd(new EventDateTime().setDateTime(end));

		event.setDescription(assignment.getSummary());
		try {
			m_service.events().insert(m_calendarId, event).execute();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public boolean assignmentExists(Assignment assignment) {
		Date startDate = assignment.getDate();
		DateTime start = new DateTime(startDate, TimeZone.getTimeZone("EDT"));
		EventDateTime startEDT = new EventDateTime().setDateTime(start);

		for (Event e : m_eventCache) {
			if (assignment.getAssignment().equals(e.getSummary())) {
				return true;
			}
		}
		return false;
	}
}
