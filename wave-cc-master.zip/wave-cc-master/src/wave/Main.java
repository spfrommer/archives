package wave;

import java.util.List;

import wave.google.GAccountView;
import wave.google.GCalendar;
import wave.google.GClassroom;
import wave.google.GCredentials;
import wave.gui.CoverupGui;

public class Main {
	public static void main(String[] args) {
		GCredentials credentials = LoginHandler.instance().getCredentials();
		List<ClassroomToCalendar> ccs = ClassroomToCalendarHandler.instance().getClassroomToCalendars();

		CoverupGui.instance().startCoverup();
		GAccountView account = new GAccountView(credentials);
		String calendarCode = Utils.getCalendarAuthCode(account);
		// String calendarCode = "";
		for (ClassroomToCalendar cc : ccs) {
			syncCalendar(account, cc, calendarCode);
		}

		CoverupGui.instance().stopCoverup();
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		account.close();
		System.exit(0);
	}

	private static void syncCalendar(GAccountView account, ClassroomToCalendar cc, String calendarCode) {
		GClassroom classroom = new GClassroom(account, cc.getClassroomUrl());

		List<Assignment> assignments = classroom.loadAssignments();

		GCalendar calendar = new GCalendar(account, cc.getCalendarID(), calendarCode);
		for (Assignment assignment : assignments) {
			System.out.println(assignment);
			if (!calendar.assignmentExists(assignment)) {
				calendar.addAssignment(assignment);
			}
		}
	}
}