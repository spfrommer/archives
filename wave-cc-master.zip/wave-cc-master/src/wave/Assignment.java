package wave;

import java.util.Date;

public class Assignment {
	private Date m_date;
	private String m_assignment;
	private String m_summary;

	public Assignment(Date date, String assignment, String summary) {
		m_date = date;
		m_assignment = assignment;
		m_summary = summary;
	}

	public Date getDate() {
		return m_date;
	}

	public String getAssignment() {
		return m_assignment;
	}

	public String getSummary() {
		return m_summary;
	}

	@Override
	public String toString() {
		return m_date.toString() + ": " + m_assignment + " : " + m_summary;
	}

	@Override
	public boolean equals(Object other) {
		if (!(other instanceof Assignment)) {
			return false;
		} else if (this == other) {
			return true;
		} else {
			Assignment o = (Assignment) other;
			if (m_assignment.equals(o.m_assignment) && m_date.equals(o.m_date)) {
				return true;
			} else {
				return false;
			}
		}
	}
}
