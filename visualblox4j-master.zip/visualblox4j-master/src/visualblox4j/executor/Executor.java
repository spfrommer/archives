package visualblox4j.executor;

import visualblox4j.model.Program;
import visualblox4j.model.function.Function;

public class Executor {
	private Program m_model;

	public Executor(Program model) {
		m_model = model;
	}

	public void execute() {
		Function function = m_model.getFunction("main");
	}
}
