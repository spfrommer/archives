package visualblox4j.model;

public enum ValueType {
	NUMBER, STRING, BOOLEAN
}
