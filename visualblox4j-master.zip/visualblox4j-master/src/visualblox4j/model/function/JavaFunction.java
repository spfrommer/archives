package visualblox4j.model.function;

public class JavaFunction extends Function {

}
