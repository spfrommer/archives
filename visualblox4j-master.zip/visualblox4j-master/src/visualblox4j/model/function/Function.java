package visualblox4j.model.function;

import java.util.List;

import visualblox4j.model.ValueType;

public abstract class Function {
	private String m_name;
	private List<ValueType> m_argumentTypes;

	public Function() {
		super();
	}

	public Function(String name, List<ValueType> argumentTypes) {
		super();
		m_name = name;
		m_argumentTypes = argumentTypes;
	}

	public String getName() {
		return m_name;
	}

	public void setName(String name) {
		m_name = name;
	}

	public List<ValueType> getArgumentTypes() {
		return m_argumentTypes;
	}

	public void setArgumentTypes(List<ValueType> argumentTypes) {
		m_argumentTypes = argumentTypes;
	}
}
