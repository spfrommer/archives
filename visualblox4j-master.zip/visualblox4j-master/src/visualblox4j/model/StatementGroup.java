package visualblox4j.model;

import java.util.ArrayList;
import java.util.List;

public class StatementGroup {
	private List<Statement> m_statements;

	public StatementGroup() {
		m_statements = new ArrayList<Statement>();
	}

	public StatementGroup(List<Statement> statements) {
		m_statements = statements;
	}

	public List<Statement> getStatements() {
		return m_statements;
	}

	public void setStatements(List<Statement> statements) {
		m_statements = statements;
	}
}
