package visualblox4j.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import visualblox4j.model.function.Function;

public class Program {
	private Map<String, Function> m_functions;
	private List<StatementGroup> m_groups;

	public Program() {
		m_groups = new ArrayList<StatementGroup>();
	}

	public Function getFunction(String name) {
		return m_functions.get(name);
	}

	public void addFunction(Function function) {
		m_functions.put(function.getName(), function);
	}

	public void removeFunction(Function function) {
		m_functions.remove(function.getName());
	}

	public List<StatementGroup> getAllGroups() {
		return m_groups;
	}

	public void addFloatingBlocks(StatementGroup floatingBlocks) {
		m_groups.add(floatingBlocks);
	}

	public void removeFloatingBlocks(StatementGroup floatingBlocks) {
		m_groups.remove(floatingBlocks);
	}
}
