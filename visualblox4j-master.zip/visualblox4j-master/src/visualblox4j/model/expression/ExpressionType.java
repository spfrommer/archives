package visualblox4j.model.expression;

public enum ExpressionType {
	ADD, SUBTRACT
}
