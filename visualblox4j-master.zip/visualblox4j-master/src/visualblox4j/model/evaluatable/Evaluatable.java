package visualblox4j.model.evaluatable;

public interface Evaluatable<ValueType> {

}
