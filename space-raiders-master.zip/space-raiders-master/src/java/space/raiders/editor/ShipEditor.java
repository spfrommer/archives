package space.raiders.editor;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import engine.commons.utils.Vector2f;

public class ShipEditor extends JFrame {
	private static final long serialVersionUID = 1L;

	private static final String MOUNT_ICON_PATH = "/Editor/Ship/mounticon.png";
	private static final String REMOVE_ICON_PATH = "/Editor/Ship/removeicon.png";
	private static final int MOUNT_ICON_WIDTH = 20;
	private static final int MOUNT_ICON_HEIGHT = 20;

	private static final int REMOVE_ICON_WIDTH = 20;
	private static final int REMOVE_ICON_HEIGHT = 20;

	public enum PlacementType {
		NONE, MOUNT, REMOVE
	}

	// File to save to
	private File m_saveFile;

	private String m_shipImagePath;
	private String m_normalImagePath;
	private ArrayList<Point2D> m_mounts = new ArrayList<Point2D>();

	private BufferedImage m_shipImage;

	private JPanel m_mainPanel;
	private EditorPanel m_editor;
	private JPanel m_bottomPanel;
	private JMenuBar m_menuBar;

	private JTextField m_nameField;

	private PlacementType m_placementType = PlacementType.NONE;

	public ShipEditor() {
		m_mainPanel = new JPanel();
		m_editor = new EditorPanel();
		m_bottomPanel = new JPanel();
		m_menuBar = new JMenuBar();

		m_nameField = new JTextField(10);

		JMenu fileMenu = new JMenu("File");
		JMenuItem save = new JMenuItem("Save");
		save.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					ShipEditor.this.save();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		JMenuItem saveAs = new JMenuItem("Save As");
		saveAs.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					ShipEditor.this.chooseSaveFile();
					if (m_saveFile != null)
						ShipEditor.this.save();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		JMenuItem load = new JMenuItem("Load");
		load.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser fileChooser = new JFileChooser();
				fileChooser.setCurrentDirectory(new File("src/resources"));
				int result = fileChooser.showOpenDialog(ShipEditor.this);
				if (result == JFileChooser.APPROVE_OPTION) {
					File selectedFile = fileChooser.getSelectedFile();
					try {
						ShipEditor.this.load(selectedFile);
					} catch (SAXException e1) {
						e1.printStackTrace();
					} catch (IOException e1) {
						e1.printStackTrace();
					} catch (ParserConfigurationException e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		fileMenu.add(save);
		fileMenu.add(saveAs);
		fileMenu.add(load);

		JMenu imageMenu = new JMenu("Image");
		JMenuItem diffuseImageSet = new JMenuItem("Set Diffuse Image...");
		diffuseImageSet.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// Load image
				JFileChooser fileChooser = new JFileChooser();
				fileChooser.setCurrentDirectory(new File("src/resources"));
				int result = fileChooser.showOpenDialog(ShipEditor.this);
				if (result == JFileChooser.APPROVE_OPTION) {
					File selectedFile = fileChooser.getSelectedFile();
					File dir = new File("src/resources");
					m_shipImagePath = getRelativePath(selectedFile, dir);
					System.out.println("Selected file: " + m_shipImagePath);
					try {
						m_shipImage = ImageIO.read(selectedFile);
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
				ShipEditor.this.getContentPane().repaint();
			}
		});
		JMenuItem normalImageSet = new JMenuItem("Set Normal Image...");
		normalImageSet.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// Load image
				JFileChooser fileChooser = new JFileChooser();
				fileChooser.setCurrentDirectory(new File("src/resources"));
				int result = fileChooser.showOpenDialog(ShipEditor.this);
				if (result == JFileChooser.APPROVE_OPTION) {
					File selectedFile = fileChooser.getSelectedFile();
					File dir = new File("src/resources");
					m_normalImagePath = getRelativePath(selectedFile, dir);
					System.out.println("Selected normal file: " + m_shipImagePath);
				}
			}
		});

		imageMenu.add(diffuseImageSet);
		imageMenu.add(normalImageSet);

		m_menuBar.add(fileMenu);
		m_menuBar.add(imageMenu);

		JButton addMount = new JButton("Add Mount");
		addMount.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				m_placementType = PlacementType.MOUNT;
			}
		});
		JButton removeMount = new JButton("Remove Mount");
		removeMount.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				m_placementType = PlacementType.REMOVE;
			}
		});

		m_bottomPanel.add(m_nameField);
		m_bottomPanel.add(addMount);
		m_bottomPanel.add(removeMount);

		m_mainPanel.setLayout(new BorderLayout());

		m_mainPanel.add(m_editor, BorderLayout.CENTER);
		m_mainPanel.add(m_bottomPanel, BorderLayout.SOUTH);

		setJMenuBar(m_menuBar);
		getContentPane().add(m_mainPanel);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(500, 500);
	}

	public String getXML() {
		StringBuilder builder = new StringBuilder();
		builder.append("<xml>").append('\n');
		builder.append('\t').append("<ship name=\"").append(m_nameField.getText()).append("\">").append('\n');
		if (m_shipImagePath != null)
			builder.append('\t').append('\t').append("<diffuse-texture res=\"").append(m_shipImagePath).append("\"/>")
					.append('\n');
		if (m_normalImagePath != null)
			builder.append('\t').append('\t').append("<normal-texture res=\"").append(m_normalImagePath).append("\"/>")
					.append('\n');
		for (Point2D mount : m_mounts) {
			builder.append('\t').append('\t').append("<mount-point x=\"").append((int) mount.getX()).append("\" y=\"")
					.append((int) mount.getY()).append("\"/>").append('\n');
		}
		builder.append('\t').append("</ship>").append('\n');
		builder.append("</xml>").append('\n');
		return builder.toString();
	}

	public void chooseSaveFile() {
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setCurrentDirectory(new File("src/resources"));
		int result = fileChooser.showSaveDialog(ShipEditor.this);
		if (result == JFileChooser.APPROVE_OPTION) {
			File selectedFile = fileChooser.getSelectedFile();
			System.out.println("Selected save file" + selectedFile.getAbsolutePath());
			m_saveFile = selectedFile;
		}
	}

	public void save() throws IOException {
		if (m_saveFile == null)
			chooseSaveFile();
		if (m_saveFile == null)
			return;
		PrintWriter out = new PrintWriter(new FileWriter(m_saveFile));
		out.println(getXML());
		out.flush();
		out.close();
	}

	public void load(File file) throws SAXException, IOException, ParserConfigurationException {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(file);
		Element ship = (Element) doc.getElementsByTagName("ship").item(0);
		m_nameField.setText(ship.getAttribute("name"));
		String diffuse = "";
		String normal = "";
		if (ship.getElementsByTagName("diffuse-texture").getLength() > 0)
			diffuse = ((Element) ship.getElementsByTagName("diffuse-texture").item(0)).getAttribute("res");
		if (ship.getElementsByTagName("normal-texture").getLength() > 0)
			normal = ((Element) ship.getElementsByTagName("normal-texture").item(0)).getAttribute("res");
		m_shipImagePath = diffuse;
		// Load ship image
		m_shipImage = ImageIO.read(ShipEditor.class.getResourceAsStream("/" + m_shipImagePath));

		m_normalImagePath = normal;

		NodeList mounts = ship.getElementsByTagName("mount-point");
		for (int i = 0; i < mounts.getLength(); i++) {
			Element m = (Element) mounts.item(i);
			int x = Integer.parseInt(m.getAttribute("x"));
			int y = Integer.parseInt(m.getAttribute("y"));
			m_mounts.add(new Point2D.Float(x, y));
		}
		m_saveFile = file;
	}

	public static void main(String[] args) {
		new ShipEditor().setVisible(true);
	}

	public class EditorPanel extends JPanel {
		private static final long serialVersionUID = 1L;

		private int m_mouseX;
		private int m_mouseY;

		private BufferedImage m_mountIcon;
		private BufferedImage m_removeIcon;

		public EditorPanel() {
			addMouseMotionListener(new MouseMotionListener() {
				@Override
				public void mouseDragged(MouseEvent e) {
				}

				@Override
				public void mouseMoved(MouseEvent e) {
					m_mouseX = e.getX();
					m_mouseY = e.getY();
					ShipEditor.this.getContentPane().repaint();
				}
			});
			this.addMouseListener(new MouseListener() {
				@Override
				public void mouseClicked(MouseEvent e) {
				}

				@Override
				public void mousePressed(MouseEvent e) {
				}

				@Override
				public void mouseReleased(MouseEvent e) {
					if (m_placementType == PlacementType.MOUNT)
						m_mounts.add(new Point2D.Float(e.getX(), e.getY()));
					if (m_placementType == PlacementType.REMOVE) {
						Vector2f mp = new Vector2f(e.getX(), e.getY());
						for (int i = 0; i < m_mounts.size(); i++) {
							Point2D mount = m_mounts.get(i);
							float dx = ((int) mount.getX()) - m_mouseX;
							float dy = ((int) mount.getY()) - m_mouseY;
							if (Math.sqrt(dx * dx + dy * dy) <= MOUNT_ICON_WIDTH) {
								m_mounts.remove(i);
								break;
							}
						}
					}
				}

				@Override
				public void mouseEntered(MouseEvent e) {
				}

				@Override
				public void mouseExited(MouseEvent e) {
				}
			});
			try {
				m_mountIcon = ImageIO.read(EditorPanel.class.getResourceAsStream(MOUNT_ICON_PATH));
				m_removeIcon = ImageIO.read(EditorPanel.class.getResourceAsStream(REMOVE_ICON_PATH));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		@Override
		public void paintComponent(Graphics g) {
			if (m_shipImage != null)
				g.drawImage(m_shipImage, 0, 0, null);
			for (Point2D mount : m_mounts) {
				paintMount(g, (int) mount.getX(), (int) mount.getY());
			}
			switch (m_placementType) {
			case NONE:
				;
				break;
			case MOUNT:
				paintMount(g, m_mouseX, m_mouseY);
				break;
			case REMOVE:
				paintRemove(g, m_mouseX, m_mouseY);
				break;
			}
		}

		public void paintMount(Graphics g, int x, int y) {
			g.drawImage(m_mountIcon, x - (int) (0.5 * MOUNT_ICON_WIDTH), y - (int) (0.5 * MOUNT_ICON_HEIGHT),
					MOUNT_ICON_WIDTH, MOUNT_ICON_HEIGHT, null);
		}

		public void paintRemove(Graphics g, int x, int y) {
			g.drawImage(m_removeIcon, x - (int) (0.5 * REMOVE_ICON_WIDTH), y - (int) (0.5 * REMOVE_ICON_HEIGHT),
					REMOVE_ICON_WIDTH, REMOVE_ICON_HEIGHT, null);
		}
	}

	// returns null if file isn't relative to folder
	public static String getRelativePath(File file, File folder) {
		String filePath = file.getAbsolutePath();
		String folderPath = folder.getAbsolutePath();
		if (filePath.startsWith(folderPath)) {
			return filePath.substring(folderPath.length() + 1);
		} else {
			return null;
		}
	}
}
