package game.level;

import engine.commons.utils.Vector2f;
import engine.core.frame.Component;
import engine.core.frame.Entity;
import game.entity.SpaceShip;
import game.entity.SpaceShipDef;
import game.entity.Turret;
import game.entity.TurretDef;
import gltools.ResourceLocator;

import java.io.IOException;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class LevelXMLLoader {
	public static final String[] searchPackages = { "game" };

	public static void s_load(String resource, ResourceLocator loc, List<SpaceShipDef> spaceShipDefs,
			List<TurretDef> turretDefs, Level level) throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(loc.getResource(resource));

		NodeList sList = doc.getElementsByTagName("ship");
		for (int i = 0; i < sList.getLength(); i++) {
			Element element = (Element) sList.item(i);
			level.addEntity(s_parseSpaceship(element, spaceShipDefs, turretDefs, level));
		}
		NodeList eList = doc.getElementsByTagName("entity");
		for (int i = 0; i < eList.getLength(); i++) {
			Element element = (Element) eList.item(i);
			level.addEntity(s_parseEntity(element, level));
		}
	}

	public static SpaceShip s_parseSpaceship(Element el, List<SpaceShipDef> defs, List<TurretDef> turretDefs, Level l) {
		SpaceShip ship = null;
		String type = el.getAttribute("type");
		String healthSTR = el.getAttribute("health");
		for (SpaceShipDef def : defs) {
			if (def.getName().equals(type)) {
				ship = def.createShip(l);
			}
		}
		if (healthSTR != null && !healthSTR.equals("")) {
			float health = Float.parseFloat(el.getAttribute("health"));
			ship.setData("rai_health", health);
		}
		boolean camFollow = Boolean.parseBoolean(el.getAttribute("follow"));
		if (camFollow)
			l.getCamera().setData("sys_camTargetEntity", ship);
		NodeList nodes = el.getChildNodes();
		for (int n = 0; n < nodes.getLength(); n++) {
			Node nd = nodes.item(n);
			if (nd instanceof Element) {
				Element elm = (Element) nd;
				if (elm.getTagName().equals("turrets")) {
					NodeList turrets = elm.getChildNodes();
					for (int i = 0; i < turrets.getLength(); i++) {
						Node node = turrets.item(i);
						if (node instanceof Element) {
							Element e = (Element) node;
							Turret tur = s_parseTurret(e, l, ship, turretDefs);
							l.addEntity(tur);
						}
					}
				}
			}
		}

		s_parseEntityStuff(el, ship);
		return ship;
	}

	private static Turret s_parseTurret(Element e, Level l, SpaceShip s, List<TurretDef> turretDefs) {
		String type = e.getAttribute("type");
		int mountIndex = Integer.parseInt(e.getAttribute("mountIndex"));
		Vector2f mount = s.getMountPoints().get(mountIndex);
		Turret t = null;
		for (TurretDef def : turretDefs) {
			if (def.getName().equals(type)) {
				t = def.create(l, s, mount);
			}
		}
		s_parseEntityStuff(e, t);
		return t;
	}

	public static Entity s_parseEntity(Element el, Level l) {
		Entity entity = new Entity(l);
		s_parseEntityStuff(el, entity);
		return entity;
	}

	public static void s_parseEntityStuff(Element e, Entity entity) {
		NodeList nodes = e.getChildNodes();
		for (int n = 0; n < nodes.getLength(); n++) {
			Node nd = nodes.item(n);
			if (nd instanceof Element) {
				Element elm = (Element) nd;
				if (elm.getTagName().equals("components")) {
					NodeList components = elm.getChildNodes();
					for (int i = 0; i < components.getLength(); i++) {
						Node node = components.item(i);
						if (node instanceof Element) {
							Element element = (Element) node;
							entity.addComponent(s_parseComponent(element));
						}
					}
				} else if (elm.getTagName().equals("fields")) {
					NodeList fields = elm.getChildNodes();
					for (int i = 0; i < fields.getLength(); i++) {
						Node node = fields.item(i);
						if (node instanceof Element) {
							Element element = (Element) node;
							s_applyField(element, entity);
						}
					}
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	public static Component s_parseComponent(Element e) {
		String className = e.getTagName();
		Class<Component> clazz = null;
		Component c = null;
		try {
			clazz = (Class<Component>) findClassByName(className);
			c = clazz.newInstance();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return c;
	}

	public static void s_applyField(Element e, Entity entity) {
		if (e.getTagName().equals("position")) {
			((Body) entity.getData("sys_body")).setTransform(
					new Vec2(Float.parseFloat(e.getAttribute("x")), Float.parseFloat(e.getAttribute("y"))), 0);
			;
		}
	}

	public static Class<?> findClassByName(String name) {
		for (int i = 0; i < searchPackages.length; i++) {
			try {
				return Class.forName(searchPackages[i] + "." + name);
			} catch (ClassNotFoundException e) {
				// not in this package, try another
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}
}
