package game.level;

import org.jbox2d.dynamics.BodyType;

import engine.commons.utils.Vector2f;
import engine.core.exec.MaterialPool;
import engine.core.frame.Entity;
import engine.core.frame.World;
import engine.core.imp.physics.PhysicsManager;
import engine.core.imp.physics.collision.NoCollisionFilter;
import engine.core.imp.render.FollowCameraControllerComponent;
import engine.core.imp.render.ParallaxRenderComponent;
import engine.core.presets.PhysicsGameFactory;
import game.RaiderFieldInitializer;

public class Level extends World {
	private PhysicsManager m_physics;
	private PhysicsGameFactory m_factory;
	private Entity m_camera;

	public Level() {
		super();
		m_physics = new PhysicsManager(new Vector2f(0f, 0f));
		this.addDataManager(m_physics);
		this.addFieldInitializer(new RaiderFieldInitializer());
		m_factory = new PhysicsGameFactory(this, m_physics);
		// make the background
		for (int i = 1; i < 5; i++) {
			Entity stars1 = m_factory.createTexturedSolid(new Vector2f(0f, 0f), 0f, new Vector2f(40f, 40f),
					BodyType.STATIC, MaterialPool.materials.get("starbackground3"), new ParallaxRenderComponent());
			m_physics.getCollisionFilter().addFilter(stars1, new NoCollisionFilter());
			stars1.setUpdateOrder(2);
			stars1.setData("sys_parallaxDepth", i + 1f);
			stars1.setData("sys_repeatMaterial", true);
			stars1.setData("sys_repeatCount", 100f);
			this.addEntity(stars1);
		}

		/*
		 * Entity stars2 = m_factory.createTexturedSolid(new Vector2f(1.75f,
		 * 1.5f), 0f, new Vector2f(15f, 15f), BodyType.STATIC,
		 * MaterialPool.materials.get("starbackground3"), new
		 * ParalaxRenderComponent()); stars2.setUpdateOrder(2);
		 * stars2.setData("sys_paralaxDepth", 1f);
		 * stars2.setData("sys_repeatMaterial", true);
		 * stars2.setData("sys_repeatCount", 10f); this.addEntity(stars2);
		 * 
		 * Entity stars3 = m_factory.createTexturedSolid(new Vector2f(1.75f,
		 * 1.5f), 0f, new Vector2f(15f, 15f), BodyType.STATIC,
		 * MaterialPool.materials.get("starbackground3"), new
		 * ParalaxRenderComponent()); stars3.setUpdateOrder(3);
		 * stars3.setData("sys_paralaxDepth", 2f);
		 * stars3.setData("sys_repeatMaterial", true);
		 * stars3.setData("sys_repeatCount", 10f); this.addEntity(stars3);
		 */

		// add the ambient light
		/*
		 * Entity light = new Entity(this); light.setData("sys_lights",
		 * Arrays.asList(new PointLight(new Vector3f(5f, 5f, 5f), new
		 * Vector3f(0f, 0f, 0.05f), new Color(0f, 0f, 0f), new Color(1f, 1f, 1f,
		 * 1f)))); light.addComponent(new LightComponent());
		 * light.setUpdateOrder(1); this.addEntity(light);
		 */

		// add the camera
		m_camera = new Entity(this);
		// m_camera.setData("sys_camPosition", new Vector2f(0f, 0f));
		m_camera.setData("sys_camScale", new Vector2f(1f, 1f));
		m_camera.setData("sys_camRotation", 0f);
		m_camera.setUpdateOrder(0);
		m_camera.addComponent(new FollowCameraControllerComponent());
		this.addEntity(m_camera);
	}

	public PhysicsGameFactory getFactory() {
		return m_factory;
	}

	public PhysicsManager getPhysicsManager() {
		return m_physics;
	}

	public Entity getCamera() {
		return m_camera;
	}

	public void setCamera(Entity entity) {
		removeEntity(m_camera);
		addEntity(entity);
		m_camera = entity;
	}
}
