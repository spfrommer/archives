package game;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.jbox2d.dynamics.BodyType;

import engine.commons.utils.Vector2f;
import engine.core.exec.Game;
import engine.core.exec.MaterialPool;
import engine.core.frame.Entity;
import engine.core.imp.control.KeyboardControlComponent;
import engine.core.imp.group.TagList;
import engine.core.imp.render.LightComponent;
import engine.core.imp.render.MaterialFactory;
import engine.core.imp.render.ParallaxRenderComponent;
import game.entity.ProjectileDef;
import game.entity.ProjectileXMLLoader;
import game.entity.ShipXMLLoader;
import game.entity.SpaceShip;
import game.entity.SpaceShipDef;
import game.entity.Turret;
import game.entity.TurretDef;
import game.entity.TurretXMLLoader;
import game.entity.components.AITurretComponent;
import game.entity.components.EnemyAIComponent;
import game.entity.components.FriendlyAIComponent;
import game.entity.components.MouseTurretComponent;
import game.level.Level;
import game.level.LevelGame;
import glcommon.Color;
import glcommon.vector.Vector3f;
import glextra.renderer.Light.PointLight;
import gltools.ResourceLocator.ClasspathResourceLocator;
import gltools.util.FileUtils;

public class SpaceShipGame extends Game {
	private Level level1;
	public static final float SPACESHIP_DEPTH = 1f;

	List<SpaceShipDef> shipTypes = new ArrayList<SpaceShipDef>();
	List<TurretDef> turretTypes = null;

	public SpaceShipGame() {
		super("Space Raiders", 1024, 1024, 102.4f);
	}

	@Override
	protected void init() {

	}

	@Override
	public void createMaterials() {
		MaterialPool.materials.put("starbackground1",
				MaterialFactory.createBasicMaterial("Textures/starbackground1.png", false, true));
		MaterialPool.materials.put("starbackground2",
				MaterialFactory.createBasicMaterial("Textures/starbackground2.png", false, true));
		MaterialPool.materials.put("starbackground3",
				MaterialFactory.createBasicMaterial("Textures/starbackground3.png", false, true));
		MaterialPool.materials.put("sun", MaterialFactory.createBasicMaterial("Textures/sun.png", true, false));
		MaterialPool.materials.put("F5S1", MaterialFactory.createBasicMaterial("Textures/F5S1.png", true, false));
		MaterialPool.materials.put("turret1", MaterialFactory.createBasicMaterial("Textures/turret1.png", true, false));
		MaterialPool.materials.put("turret2", MaterialFactory.createBasicMaterial("Textures/turret2.png", true, false));
		MaterialPool.materials.put("turret3", MaterialFactory.createBasicMaterial("Textures/turret3.png", true, false));
		MaterialPool.materials.put("turret4", MaterialFactory.createBasicMaterial("Textures/turret4.png", true, false));
	}

	@Override
	public void onStart() {
		level1 = new Level();
		this.setCurrentWorld(level1);

		try {
			List<ProjectileDef> projectiles = ProjectileXMLLoader.s_load("Projectiles/projectiles.projectile",
					new ClasspathResourceLocator());
			turretTypes = TurretXMLLoader.s_load("Turrets/test.turret", new ClasspathResourceLocator(), projectiles);
			String contents = FileUtils.s_readAll(LevelGame.class.getResourceAsStream("/Ships/allships.txt"));
			String[] files = contents.split("\\s+");
			for (String f : files) {
				shipTypes.addAll(ShipXMLLoader.s_load("Ships/" + f, new ClasspathResourceLocator()));
			}
			// LevelXMLLoader.s_load("Levels/test.level", new
			// ClasspathResourceLocator(), shipTypes, turretTypes, level1);
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			// initialize allies
			int ran = (int) (Math.random() * 4);
			SpaceShip player = addPlayerShip(level1, shipTypes.get(ran), getTurretDef(turretTypes, "Standard"));
			player.setData("sys_position", new Vector2f(0f, 0f));
			level1.getCamera().setData("sys_camTargetEntity", player);

			for (int i = 0; i < 5; i++) {
				ran = (int) (Math.random() * 4);
				SpaceShip ally = addFriendlyShip(player, level1, shipTypes.get(ran),
						getTurretDef(turretTypes, "Standard"));
				ally.setData("sys_position", new Vector2f((-7.5f + 3 * (i + 1)), -4f));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Entity sun = level1.getFactory().createTexturedSolid(new Vector2f(-10f, -10f), 0, new Vector2f(3f, 3f),
				BodyType.STATIC, MaterialPool.materials.get("sun"), new ParallaxRenderComponent());
		sun.setData("sys_parallaxDepth", 1f);

		sun.setData("sys_lights", Arrays.asList(new PointLight(new Vector3f(-10f, -10f, 5f), new Vector3f(0.1f, 0.02f,
				0.005f), new Color(1f, 1f, 1f), new Color(0.1f, 0.1f, 0.1f, 0.1f))));
		sun.addComponent(new LightComponent());
		sun.setUpdateOrder(1);
		level1.addEntity(sun);
	}

	public SpaceShip addPlayerShip(Level level, SpaceShipDef shipDef, TurretDef turretDef) {
		SpaceShip ship = shipDef.createShip(level1);
		ship.setData("sys_groups", new TagList("allies"));
		ship.setData("rai_health", 100f);
		for (Vector2f mount : ship.getMountPoints()) {
			Turret turret = turretDef.create(level1, ship, mount);
			turret.setData("rai_gunRechargeTime", 0.1f);
			// turret.setData("sys_groups", new TagList("allies"));
			turret.setData("rai_level", level);
			turret.addComponent(new MouseTurretComponent());

			getCurrentWorld().addEntity(turret);
		}
		ship.addComponent(new KeyboardControlComponent());

		level.addEntity(ship);

		return ship;
	}

	public SpaceShip addFriendlyShip(SpaceShip mothership, Level level, SpaceShipDef shipDef, TurretDef turretDef) {
		SpaceShip ship = shipDef.createShip(level1);
		ship.setData("sys_groups", new TagList("allies"));
		ship.setData("rai_health", 30f);
		ship.setData("rai_mothership", mothership);
		for (Vector2f mount : ship.getMountPoints()) {
			Turret turret = turretDef.create(level1, ship, mount);
			// turret.setData("sys_groups", new TagList("allies"));
			turret.setData("rai_level", level);
			turret.setData("rai_targetGroup", "enemies");
			turret.addComponent(new AITurretComponent());

			getCurrentWorld().addEntity(turret);
		}
		ship.addComponent(new FriendlyAIComponent());

		level.addEntity(ship);

		return ship;
	}

	public SpaceShip addEnemyShip(Level level, SpaceShipDef shipDef, TurretDef turretDef) {
		SpaceShip ship = shipDef.createShip(level1);
		ship.setData("sys_groups", new TagList("enemies"));
		ship.setData("rai_health", 30f);
		for (Vector2f mount : ship.getMountPoints()) {
			Turret turret = turretDef.create(level1, ship, mount);
			// turret.setData("sys_groups", new TagList("enemies"));
			turret.setData("rai_level", level);
			turret.setData("rai_targetGroup", "allies");
			turret.addComponent(new AITurretComponent());

			getCurrentWorld().addEntity(turret);
		}
		ship.addComponent(new EnemyAIComponent());

		level.addEntity(ship);

		return ship;
	}

	public SpaceShipDef getShipDef(List<SpaceShipDef> defs, String name) {
		for (SpaceShipDef def : defs) {
			if (def.getName().equals(name)) {
				return def;
			}
		}
		return null;
	}

	public TurretDef getTurretDef(List<TurretDef> defs, String name) {
		for (TurretDef def : defs) {
			if (def.getName().equals(name)) {
				return def;
			}
		}
		return null;
	}

	private int counter = 0;

	@Override
	protected void preUpdate() {
		counter++;
		if (counter >= 120) {
			int ran = (int) (Math.random() * 4) + 13;
			SpaceShip enemy = addEnemyShip(level1, shipTypes.get(ran), getTurretDef(turretTypes, "StandardCamo"));
			enemy.setData("sys_position", new Vector2f(0f, 30f));
			counter = 0;
		}
	}

	@Override
	protected void postUpdate() {

	}

	public static void main(String[] args) {
		SpaceShipGame game = new SpaceShipGame();
		game.start();
	}
}
