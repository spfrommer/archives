package game;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import engine.core.frame.FieldInitializer;

public class RaiderFieldInitializer implements FieldInitializer {
	private static final Set<String> IDENTIFIERS = new HashSet<String>(Arrays.asList("rai_damage", "rai_health",
			"rai_projectileDef", "rai_gunRechargeTime", "rai_level", "rai_targetGroup", "rai_mothership"));

	public Set<String> getDataIdentifiers() {
		return IDENTIFIERS;
	}

	public Object createObjectFor(String identifier) {
		if (identifier.equals("rai_damage"))
			return 1f;
		if (identifier.equals("rai_health"))
			return 10f;
		if (identifier.equals("rai_projectileDef"))
			return null;
		if (identifier.equals("rai_gunRechargeTime"))
			return 1 / 60f;
		if (identifier.equals("rai_level"))
			return null;
		if (identifier.equals("rai_targetGroup"))
			return "enemies";
		if (identifier.equals("rai_mothership"))
			return null;

		return null;
	}
}
