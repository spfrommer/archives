package game.entity.components;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;

import engine.core.exec.GameState;
import engine.core.frame.Component;
import engine.core.frame.Entity;

public class FriendlyAIComponent extends Component {
	private static final Set<String> IDENTIFIERS = new HashSet<String>(Arrays.asList("sys_body", "rai_mothership"));

	private boolean m_toggleFollow = false;

	@Override
	public void update(float time, GameState state) {
		Body body = (Body) getData("sys_body");
		Entity motherShip = (Entity) getData("rai_mothership");
		Body motherBody = (Body) motherShip.getData("sys_body");

		if (state.keyboard.isKeyPressed(state.keyboard.getKey('e'))) {
			m_toggleFollow = false;
			Vec2 difVect = motherBody.getTransform().p.clone().sub(body.getTransform().p.clone());

			body.setTransform(body.getTransform().p, (float) (Math.atan2(difVect.y, difVect.x) - Math.PI / 2));
			body.setLinearVelocity(difVect.mul(0.8f));
		} else if (m_toggleFollow == true || state.keyboard.isKeyPressed(state.keyboard.getKey('q'))) {
			m_toggleFollow = true;
			body.setTransform(body.getTransform().p, motherBody.getAngle());
			body.setLinearVelocity(motherBody.getLinearVelocity());
		}
	}

	@Override
	public Set<String> getDataIdentifiers() {
		return IDENTIFIERS;
	}
}
