package game.entity.components;

import engine.core.frame.Entity;
import engine.core.imp.physics.collision.CollisionEvent;
import game.entity.SpaceShip;
import game.level.Level;

public class ProjectileCollisionHandler implements CollisionEvent {
	private float m_damage;
	private Level m_level;
	private Entity m_projectile;

	public ProjectileCollisionHandler(float damage, Level level, Entity projectile) {
		m_damage = damage;
		m_level = level;
		m_projectile = projectile;
	}

	public void collidedWith(Entity entity) {
		if (entity.hasDataFor("rai_health")) {
			float health = (Float) entity.getData("rai_health");
			entity.setData("rai_health", health - m_damage);

			if (health - m_damage <= 0)
				((SpaceShip) entity).removeFromLevel(m_level);
		}

		m_level.removeEntity(m_projectile);
	}
}
