package game.entity.components;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;

import engine.commons.utils.Vector2f;
import engine.core.exec.GameState;
import engine.core.frame.Component;
import engine.core.frame.Entity;

public class EnemyAIComponent extends Component {
	private static final Set<String> IDENTIFIERS = new HashSet<String>(Arrays.asList("sys_body"));
	private boolean near = false;

	@Override
	public void update(float time, GameState state) {
		Body body = (Body) getData("sys_body");
		Vector2f ourPos = new Vector2f(body.getPosition());
		List<Entity> targets = this.getWorld().getGroupManager().getEntities("allies");

		Entity nearest = null;
		Vector2f nDif = null;
		float nearLength = 10000f;
		for (Entity e : targets) {
			Vector2f ePos = (Vector2f) e.getData("sys_position");
			Vector2f dif = ePos.sub(ourPos);
			float length = dif.length();
			if (length < nearLength) {
				nearLength = length;
				nDif = dif;
				nearest = e;
			}
		}
		if (nearest != null && nDif.length() != 0) {
			/*if (nearLength < 5f) {
				near = true;
			}*/

			if (nearLength > 6f) {
				near = false;
			}
			if (near) {
				float angle = nDif.angle();

				Vec2 directionVector = new Vec2((float) Math.cos(body.getAngle() + Math.PI / 2), (float) Math.sin(body
						.getAngle() + Math.PI / 2));

				body.setTransform(body.getTransform().p, angle);
				body.setLinearVelocity(directionVector.mul(100f * time));
			} else {
				float angle = nDif.angle();

				Vec2 directionVector = new Vec2((float) Math.cos(body.getAngle() + (float) Math.PI / 2),
						(float) Math.sin(body.getAngle() + (float) Math.PI / 2));

				body.setTransform(body.getTransform().p, angle - (float) Math.PI / 2);
				body.setLinearVelocity(directionVector.mul(500f * time));
			}
		}
	}

	@Override
	public Set<String> getDataIdentifiers() {
		return IDENTIFIERS;
	}
}
