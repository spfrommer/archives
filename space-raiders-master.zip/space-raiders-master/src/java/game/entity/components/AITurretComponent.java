package game.entity.components;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.jbox2d.dynamics.Body;

import engine.commons.utils.Vector2f;
import engine.core.exec.GameState;
import engine.core.frame.Entity;
import game.level.Level;

public class AITurretComponent extends TurretComponent {
	private static final Set<String> IDENTIFIERS = new HashSet<String>(Arrays.asList("sys_body", "rai_projectileDef",
			"rai_gunRechargeTime", "rai_level", "rai_targetGroup"));

	@Override
	public void update(float time, GameState state) {
		Level level = (Level) getData("rai_level");
		String targetGroup = (String) getData("rai_targetGroup");
		Body body = (Body) getData("sys_body");
		Vector2f tPos = new Vector2f(body.getPosition());
		List<Entity> targets = level.getGroupManager().getEntities(targetGroup);

		Entity nearest = null;
		Vector2f nDif = null;
		float nearLength = 10000f;

		for (Entity e : targets) {
			Vector2f ePos = (Vector2f) e.getData("sys_position");
			Vector2f dif = ePos.sub(tPos);
			float length = dif.length();
			if (length < nearLength) {
				nearLength = length;
				nDif = dif;
				nearest = e;
			}
		}

		doTime(time);
		if (nearest != null && nDif.length() != 0 && nearLength < 8f) {
			float angle = nDif.angle();

			body.setTransform(body.getTransform().p, angle - (float) Math.PI / 2);

			doFire();
		}
	}

	@Override
	public Set<String> getDataIdentifiers() {
		return IDENTIFIERS;
	}
}
