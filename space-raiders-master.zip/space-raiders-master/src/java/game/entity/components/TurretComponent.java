package game.entity.components;

import org.jbox2d.dynamics.Body;

import engine.core.frame.Component;
import game.entity.Projectile;
import game.entity.ProjectileDef;
import game.entity.SpaceShip;
import game.entity.Turret;
import game.level.Level;

public abstract class TurretComponent extends Component {
	private float m_gunHeat = 0.1f;

	public void doTime(float time) {
		m_gunHeat -= time;
	}

	public void doFire() {
		Body body = (Body) getData("sys_body");
		float rechargeTime = (Float) getData("rai_gunRechargeTime");
		ProjectileDef projectile = (ProjectileDef) getData("rai_gunProjectileDef");
		Level level = (Level) getData("rai_level");
		SpaceShip ship = (SpaceShip) getData("rai_spaceship");

		if (m_gunHeat <= 0) {
			Projectile proj = projectile.create(level, ship, (Turret) getEntity());
			level.addEntity(proj);
			m_gunHeat = rechargeTime;
		}
	}
}
