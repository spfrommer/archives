package game.entity.components;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.jbox2d.dynamics.Body;

import engine.commons.utils.Vector2f;
import engine.core.exec.GameState;
import gltools.input.Mouse;
import gltools.input.Mouse.MouseButton;

public class MouseTurretComponent extends TurretComponent {
	private static final Set<String> IDENTIFIERS = new HashSet<String>(Arrays.asList("sys_body", "rai_projectileDef",
			"rai_gunRechargeTime", "rai_level"));

	@Override
	public void update(float time, GameState state) {
		Mouse mouse = state.mouse;
		Body body = (Body) getData("sys_body");

		Vector2f mousePos = new Vector2f(mouse.getX(), mouse.getY());

		mousePos = new Vector2f((mousePos.x * state.renderer.getCSRight() * 2) / state.display.getWidth(), (mousePos.y
				* state.renderer.getCSTop() * 2)
				/ state.display.getHeight());
		mousePos = mousePos.sub(new Vector2f(state.renderer.getCSRight(), state.renderer.getCSTop()));

		// System.out.println(mousePos.angle() - (float) (Math.PI / 2));

		// System.out.println("Scale: " + state.renderer.getViewScale());
		// System.out.println("Translation: " +
		// state.renderer.getViewTranslation());

		// Inverse view transformation
		mousePos.x *= 1 / state.renderer.getViewScale().x;
		mousePos.y *= 1 / state.renderer.getViewScale().y;
		mousePos.x -= state.renderer.getViewTranslation().x;
		mousePos.y -= state.renderer.getViewTranslation().y;
		// Inverse parallax transformation

		float depth = 1f;
		float transX = -1 / depth * state.renderer.getViewTranslation().x;
		float transY = -1 / depth * state.renderer.getViewTranslation().y;

		mousePos.x += transX;
		mousePos.y += transY;

		// System.out.println("World Pos: " + mousePos);
		// System.out.println("Body Pos: " + body.getPosition());

		Vector2f toMouseVec = new Vector2f(mousePos.x - body.getPosition().x, mousePos.y - body.getPosition().y);

		body.setTransform(body.getTransform().p, toMouseVec.angle() - (float) Math.PI / 2);

		doTime(time);
		if (mouse.isButtonDown(mouse.getButton(MouseButton.LEFT_BUTTON_NAME))) {
			doFire();
		}
	}

	@Override
	public Set<String> getDataIdentifiers() {
		return IDENTIFIERS;
	}
}
