package game.entity;

import org.jbox2d.dynamics.Body;
import org.jbox2d.dynamics.BodyType;
import org.jbox2d.dynamics.joints.RevoluteJointDef;

import engine.commons.utils.Vector2f;
import engine.core.frame.Entity;
import engine.core.imp.physics.PhysicsFactory;
import engine.core.imp.physics.collision.NoCollisionFilter;
import engine.core.imp.render.ParallaxRenderComponent;
import game.SpaceShipGame;
import game.level.Level;
import glextra.material.Material;

public class Turret extends Entity {
	private ProjectileDef m_projectile;

	public Turret(Level level, Material material, Vector2f dimensions, ProjectileDef projectile, float rechargeTime,
			SpaceShip mountOn, Vector2f mountPoint, Vector2f turretOffset) {
		super(level);

		addComponent(new ParallaxRenderComponent());
		setData("rai_gunProjectileDef", projectile);
		setData("rai_gunRechargeTime", rechargeTime);
		setData("rai_level", level);
		setData("sys_dimensions", dimensions);
		setData("sys_material", material);
		setData("rai_spaceship", mountOn);
		setData("sys_parallaxDepth", SpaceShipGame.SPACESHIP_DEPTH);
		setUpdateOrder(4);

		level.getPhysicsManager().getCollisionFilter().addFilter(this, new NoCollisionFilter());
		level.getPhysicsManager().createSolid(this,
				PhysicsFactory.makeBodyDef(new Vector2f(0f, 0f), BodyType.DYNAMIC, 0f, 0f));
		Body body = ((Body) this.getData("sys_body"));
		body.setFixedRotation(true);
		body.createFixture(PhysicsFactory.makeRectangularFixtureDef(dimensions, 0, 0.00001f, 0.3f, 0.1f));

		// create the joint
		RevoluteJointDef revoluteDef = PhysicsFactory.makeRevoluteDef((Body) mountOn.getData("sys_body"),
				(Body) this.getData("sys_body"), mountPoint, turretOffset, false);
		level.getPhysicsManager().createJoint(revoluteDef);

		mountOn.register(this);
	}
}
