package game.entity;

import engine.commons.utils.Vector2f;
import glextra.material.GlobalParams;
import glextra.material.Material;
import glextra.material.MaterialXMLLoader;
import gltools.ResourceLocator;
import gltools.ResourceLocator.ClasspathResourceLocator;
import gltools.texture.Texture2D;
import gltools.texture.TextureFactory;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ShipXMLLoader {
	private static final String MAT_PATH = "Materials/2d_deferred.mat";
	private static final float CS_CONVERSION_FACTOR = 0.005f;

	public static ArrayList<SpaceShipDef> s_load(String resource, ResourceLocator locator)
			throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(locator.getResource(resource));

		ArrayList<SpaceShipDef> list = new ArrayList<SpaceShipDef>();

		NodeList nl = doc.getElementsByTagName("ship");
		for (int i = 0; i < nl.getLength(); i++) {
			Element e = (Element) nl.item(i);
			list.add(s_parseSpaceShip(e, locator));
		}
		return list;
	}

	public static SpaceShipDef s_parseSpaceShip(Element e, ResourceLocator loc) {
		String name = e.getAttribute("name");
		String diffuseTexturePath = null;
		String normalTexturePath = null;
		if (e.getElementsByTagName("diffuse-texture").getLength() > 0) {
			diffuseTexturePath = ((Element) e.getElementsByTagName("diffuse-texture").item(0)).getAttribute("res");
		}
		if (e.getElementsByTagName("normal-texture").getLength() > 0) {
			normalTexturePath = ((Element) e.getElementsByTagName("normal-texture").item(0)).getAttribute("res");
		}

		Material mat = null;
		BufferedImage diffuse = null;
		BufferedImage normal = null;
		Texture2D diffuseTex = null;
		Texture2D normalTex = null;
		try {
			if (diffuseTexturePath != null) {
				diffuse = ImageIO.read(loc.getResource(diffuseTexturePath));
				diffuse = s_rotate(diffuse, -90);
			}
			if (normalTexturePath != null) {
				normal = ImageIO.read(loc.getResource(normalTexturePath));
				normal = s_rotate(normal, -90);
			}
			mat = MaterialXMLLoader.s_load(MAT_PATH, new ClasspathResourceLocator(), GlobalParams.getInstance()).get(0);
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		if (diffuse != null)
			diffuseTex = TextureFactory.s_loadTexture(diffuse);
		if (normal != null)
			normalTex = TextureFactory.s_loadTexture(normal);

		if (diffuseTex != null)
			mat.setTexture2D("materialDiffuseTexture", diffuseTex);
		if (normalTex != null)
			mat.setTexture2D("materialNormalMap", normalTex);

		float width = diffuse.getWidth() * CS_CONVERSION_FACTOR;
		float height = diffuse.getHeight() * CS_CONVERSION_FACTOR;
		Vector2f dim = new Vector2f(width, height);

		List<Vector2f> mounts = new ArrayList<Vector2f>();

		NodeList mountList = e.getElementsByTagName("mount-point");
		// System.out.println("Image pixel dim:" + diffuse.getWidth() + " " +
		// diffuse.getHeight() + " CS DIM " + width + " " + height);
		for (int i = 0; i < mountList.getLength(); i++) {
			Element el = (Element) mountList.item(i);
			int pixelX = Integer.parseInt(el.getAttribute("x"));
			int pixelY = Integer.parseInt(el.getAttribute("y"));

			// Rotate pixelX, pixelY 90�� counter clockwise
			float tPixelX = pixelY;
			float tPixelY = diffuse.getHeight() - pixelX;

			float cPixelX = tPixelX - (int) (0.5 * diffuse.getWidth());

			// float cPixelY = tPixelY - (int) (0.5 * diffuse.getHeight());

			// For the y we need to flip vertical
			// so cPixelY = (height - pixelY) - 0.5 * height
			// or cPixelY = 0.5 * height - pixelY
			float cPixelY = (int) (0.5 * diffuse.getHeight()) - tPixelY;

			// Convert CS
			float mX = cPixelX * CS_CONVERSION_FACTOR;
			float mY = cPixelY * CS_CONVERSION_FACTOR;
			// Rotate 90�� counter clockwise
			//
			// float eX = -mY;
			// float eY = mX;
			// System.out.println("Converted: " + tPixelX + " " + tPixelY +
			// " to (pixels from center) " + cPixelX + " " + cPixelY + " " + mX
			// + " " + mY);
			mounts.add(new Vector2f(mX, mY));
		}
		return new SpaceShipDef(name, mat, dim, mounts);
	}

	/**
	 * Rotates an image. Actually rotates a new copy of the image.
	 * 
	 * @param img
	 *            The image to be rotated
	 * @param angle
	 *            The angle in degrees
	 * @return The rotated image
	 */
	public static BufferedImage s_rotate(BufferedImage img, double angle) {
		double sin = Math.abs(Math.sin(Math.toRadians(angle))), cos = Math.abs(Math.cos(Math.toRadians(angle)));

		int w = img.getWidth(null), h = img.getHeight(null);

		int neww = (int) Math.floor(w * cos + h * sin), newh = (int) Math.floor(h * cos + w * sin);

		BufferedImage image = new BufferedImage(neww, newh, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = image.createGraphics();

		g.translate((neww - w) / 2, (newh - h) / 2);
		g.rotate(Math.toRadians(angle), w / 2, h / 2);
		g.drawRenderedImage(img, null);
		g.dispose();

		return image;
	}
}
