package game.entity;

import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;
import org.jbox2d.dynamics.BodyType;

import engine.commons.utils.Vector2f;
import engine.core.frame.Entity;
import engine.core.imp.group.TagList;
import engine.core.imp.physics.PhysicsFactory;
import engine.core.imp.physics.collision.ExclusiveEntityGroupFilter;
import engine.core.imp.render.ParallaxRenderComponent;
import game.SpaceShipGame;
import game.entity.components.ProjectileCollisionHandler;
import game.level.Level;
import glextra.material.Material;

public class Projectile extends Entity {
	public Projectile(Level level, Material mat, float damage, float speed, Vector2f dimensions, SpaceShip ship,
			Vector2f pos, float angle) {
		super(level);
		addComponent(new ParallaxRenderComponent());
		setData("rai_damage", damage);
		setData("sys_dimensions", dimensions);
		setData("sys_material", mat);
		setData("sys_parallaxDepth", SpaceShipGame.SPACESHIP_DEPTH);
		setData("sys_groups", new TagList("projectile"));
		setUpdateOrder(3);

		Body shipBody = (Body) ship.getData("sys_body");

		level.getPhysicsManager().createSolid(this,
				PhysicsFactory.makeBodyDef(new Vector2f(pos.x, pos.y), BodyType.DYNAMIC, angle, 0f));
		Body pBody = ((Body) getData("sys_body"));

		pBody.createFixture(PhysicsFactory.makeRectangularFixtureDef(dimensions, 0f, 0.5f, 0.3f, 0.1f));
		pBody.setLinearVelocity(new Vec2((float) Math.cos(angle + Math.PI / 2), (float) Math.sin(angle + Math.PI / 2))
				.mul(speed + shipBody.getLinearVelocity().length()));
		level.getPhysicsManager().getCollisionFilter()
				.addFilter(this, new ExclusiveEntityGroupFilter(new TagList("projectile"), ship));

		level.getPhysicsManager().getCollisionHandler()
				.addEvent(this, new ProjectileCollisionHandler(damage, level, this));
	}
}
