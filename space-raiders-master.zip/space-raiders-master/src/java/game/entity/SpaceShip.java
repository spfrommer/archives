package game.entity;

import java.util.ArrayList;
import java.util.List;

import org.jbox2d.dynamics.Body;
import org.jbox2d.dynamics.BodyType;

import engine.commons.utils.Vector2f;
import engine.core.frame.Entity;
import engine.core.imp.physics.PhysicsFactory;
import engine.core.imp.render.ParallaxRenderComponent;
import game.SpaceShipGame;
import game.level.Level;
import glextra.material.Material;

public class SpaceShip extends Entity {
	private List<Vector2f> m_mountPoints = new ArrayList<Vector2f>();
	private List<Turret> m_registeredTurrets = new ArrayList<Turret>();

	public SpaceShip(Level level, Material material, Vector2f dimensions, List<Vector2f> mountPoints) {
		super(level);
		m_mountPoints = mountPoints;

		addComponent(new ParallaxRenderComponent());
		setData("sys_dimensions", dimensions);
		setData("sys_material", material);
		setData("sys_parallaxDepth", SpaceShipGame.SPACESHIP_DEPTH);
		setUpdateOrder(3);

		level.getPhysicsManager().createSolid(this,
				PhysicsFactory.makeBodyDef(new Vector2f(0f, 0f), BodyType.DYNAMIC, 0f, 0.01f));
		((Body) this.getData("sys_body")).createFixture(PhysicsFactory.makeRectangularFixtureDef(dimensions, 0, 1.5f,
				0.3f, 0.1f));
	}

	public void register(Turret turret) {
		m_registeredTurrets.add(turret);
	}

	public void removeFromLevel(Level level) {
		level.removeEntity(this);
		level.getPhysicsManager().destroyBody(this);
		for (Turret t : m_registeredTurrets) {
			level.getPhysicsManager().destroyBody(t);
			level.removeEntity(t);
		}
	}

	public List<Vector2f> getMountPoints() {
		return m_mountPoints;
	}
}
