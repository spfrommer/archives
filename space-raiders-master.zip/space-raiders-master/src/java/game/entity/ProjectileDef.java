package game.entity;

import engine.commons.utils.Vector2f;
import game.level.Level;
import glextra.material.Material;

import org.jbox2d.dynamics.Body;

public class ProjectileDef {
	private String m_name;
	public Material m_mat;
	public float m_damage;
	private float m_speed;
	public Vector2f m_dimensions;

	public ProjectileDef(String name, Material mat, float damage, float speed, Vector2f dimensions) {
		m_name = name;
		m_mat = mat;
		m_damage = damage;
		m_dimensions = dimensions;
		m_speed = speed;
	}

	public String getName() {
		return m_name;
	}

	public Projectile create(Level level, SpaceShip ship, Turret turret) {
		Body b = (Body) turret.getData("sys_body");
		Vector2f pos = new Vector2f(b.getPosition().x, b.getPosition().y);
		return new Projectile(level, m_mat, m_damage, m_speed, m_dimensions, ship, pos, b.getAngle());
	}
}
