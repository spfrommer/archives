package game.entity;

import engine.commons.utils.Vector2f;
import game.level.Level;
import glextra.material.Material;

public class TurretDef {
	private String m_name;
	private Material m_material;
	private Vector2f m_dimensions;
	private Vector2f m_turretOffset;
	private ProjectileDef m_projectile;
	private float m_rechargeTime;

	public TurretDef(String name, Material mat, Vector2f dimensions, Vector2f turretOffset, ProjectileDef projectile,
			float rechargeTime) {
		m_name = name;
		m_material = mat;
		m_dimensions = dimensions;
		m_turretOffset = turretOffset;
		m_projectile = projectile;
		m_rechargeTime = rechargeTime;
	}

	public String getName() {
		return m_name;
	}

	public Turret create(Level level, SpaceShip mountTarget, Vector2f mount) {
		return new Turret(level, m_material, m_dimensions, m_projectile, m_rechargeTime, mountTarget, mount,
				m_turretOffset);
	}
}
