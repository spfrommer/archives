package game.entity;

import engine.commons.utils.Vector2f;
import game.level.Level;
import glextra.material.Material;

import java.util.List;

public class SpaceShipDef {
	private String m_shipName;
	private Material m_material;
	private Vector2f m_dimensions;
	private List<Vector2f> m_mounts;

	public SpaceShipDef(String name, Material mat, Vector2f dim, List<Vector2f> mounts) {
		m_shipName = name;
		m_material = mat;
		m_dimensions = dim;
		m_mounts = mounts;
	}

	public String getName() {
		return m_shipName;
	}

	public SpaceShip createShip(Level level) {
		return new SpaceShip(level, m_material, m_dimensions, m_mounts);
	}
}
